function attachEvents() {
  const locationInput = document.getElementById("location");
  const submitButton = document.getElementById("submit");
  const forecastDiv = document.getElementById("forecast");
  const currentDiv = document.getElementById("current");
  const upcomingDiv = document.getElementById("upcoming");

  submitButton.addEventListener("click", getWeather);

  async function getWeather() {
    try {
      const locationsResponse = await fetch(
        "http://localhost:3030/jsonstore/forecaster/locations"
      );
      const locationsData = await locationsResponse.json();

      const locationName = locationInput.value;
      const location = locationsData.find((loc) => loc.name === locationName);

      if (location) {
        const [currentResponse, upcomingResponse] = await Promise.all([
          fetch(
            `http://localhost:3030/jsonstore/forecaster/today/${location.code}`
          ),
          fetch(
            `http://localhost:3030/jsonstore/forecaster/upcoming/${location.code}`
          ),
        ]);

        const currentData = await currentResponse.json();
        const upcomingData = await upcomingResponse.json();

        displayWeather(currentData, upcomingData);
      } else {
        throw new Error("Location not found");
      }
    } catch (error) {
      forecastDiv.style.display = "block";
      currentDiv.innerHTML = "<div class='label'>Error</div>";
      upcomingDiv.innerHTML = "";
    }
  }

  function displayWeather(currentData, upcomingData) {
    forecastDiv.style.display = "block";

    currentDiv.innerHTML = `
        <div class="label">Current conditions</div>
        <div class="forecast-data">
          <span class="condition symbol">${getConditionSymbol(
            currentData.forecast.condition
          )}</span>
          <span class="condition">
            <span class="forecast-data">${currentData.name}</span>
            <span class="forecast-data">${
              currentData.forecast.low
            }${getDegreeSymbol()} / ${
      currentData.forecast.high
    }${getDegreeSymbol()}</span>
            <span class="forecast-data">${currentData.forecast.condition}</span>
          </span>
        </div>
      `;

    upcomingDiv.innerHTML = `
        <div class="label">Three-day forecast</div>
        ${upcomingData.forecast
          .map(
            (day) => `
          <span class="upcoming">
            <span class="symbol">${getConditionSymbol(day.condition)}</span>
            <span class="forecast-data">${day.low}${getDegreeSymbol()} / ${
              day.high
            }${getDegreeSymbol()}</span>
            <span class="forecast-data">${day.condition}</span>
          </span>
        `
          )
          .join("")}
      `;
  }

  function getConditionSymbol(condition) {
    switch (condition) {
      case "Sunny":
        return "&#x2600;";
      case "Partly sunny":
        return "&#x26C5;";
      case "Overcast":
        return "&#x2601;";
      case "Rain":
        return "&#x2614;";
      default:
        return "";
    }
  }

  function getDegreeSymbol() {
    return "&#176;";
  }
}

attachEvents();
